import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  Request,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { PaymentEngineService } from './payment-engine.service';
import { PayrollService } from './payroll.service';
import { CalculatePaymentDto } from './dto/calculate-payment.dto';
import { CalculateToppingCommissionDto } from './dto/calculate-topping.dto';
import {
  calculateMonthlyPerformanceBonus,
  calculateToppingCommission,
} from './topping-payment-engine';

type AuthReq = { user: { userId: string; role: Role } };

@ApiTags('Payments')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('payments')
export class PaymentsController {
  constructor(
    private readonly paymentEngine: PaymentEngineService,
    private readonly payrollService: PayrollService,
  ) {}

  // ─────────────────────────────────────────────────────────────────
  // CALCULATE — any authenticated user (for their own deal preview)
  // ─────────────────────────────────────────────────────────────────
  @Post('calculate')
  @ApiOperation({ summary: 'Calculate payment breakdown from deal data' })
  calculate(@Body() dto: CalculatePaymentDto) {
    return this.paymentEngine.calculate(dto);
  }

  @Post('calculate-topping')
  @ApiOperation({ summary: 'Topping marketing commission v2 (geo node + channel rules)' })
  calculateTopping(@Body() dto: CalculateToppingCommissionDto) {
    return calculateToppingCommission(dto);
  }

  @Get('topping/monthly-bonus')
  @ApiOperation({ summary: 'Monthly performance bonus by activated customer count' })
  toppingMonthlyBonus(@Query('activeCustomers') activeCustomers: string) {
    const count = parseInt(activeCustomers ?? '0', 10);
    return { activeCustomers: count, bonus: calculateMonthlyPerformanceBonus(count) };
  }

  // ─────────────────────────────────────────────────────────────────
  // MY PAYROLL — every user sees only their own
  // ─────────────────────────────────────────────────────────────────
  @Get('payroll/me')
  @ApiOperation({ summary: 'My own monthly payroll breakdown' })
  getMyPayroll(
    @Query('baseSalary') baseSalary: string | undefined,
    @Request() req: AuthReq,
  ) {
    return this.payrollService.getMonthlyPayroll(
      req.user,
      baseSalary ? parseFloat(baseSalary) : 0,
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // TEAM PAYROLL — CEO/ADMIN only — see all users' payrolls
  // ─────────────────────────────────────────────────────────────────
  @Get('payroll/team')
  @Roles(Role.CEO, Role.ADMIN)
  @ApiOperation({ summary: '[CEO/Admin] Full team payroll summary' })
  getTeamPayroll(@Request() req: AuthReq) {
    return this.payrollService.getTeamPayroll(req.user);
  }

  // ─────────────────────────────────────────────────────────────────
  // SPECIFIC USER PAYROLL — CEO/ADMIN only
  // ─────────────────────────────────────────────────────────────────
  @Get('payroll/user/:userId')
  @Roles(Role.CEO, Role.ADMIN)
  @ApiOperation({ summary: '[CEO/Admin] View payroll for a specific user' })
  getPayrollForUser(
    @Param('userId') userId: string,
    @Query('baseSalary') baseSalary: string | undefined,
    @Request() req: AuthReq,
  ) {
    return this.payrollService.getPayrollForUser(
      userId,
      req.user,
      baseSalary ? parseFloat(baseSalary) : 0,
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // SEND PAYROLL TO ONE EMPLOYEE — CEO/ADMIN only
  // Employee receives email with their own payroll — cannot trigger this themselves
  // ─────────────────────────────────────────────────────────────────
  @Post('payroll/send/:userId')
  @Roles(Role.CEO, Role.ADMIN)
  @ApiOperation({ summary: '[CEO/Admin] Email payroll to a specific employee' })
  sendPayrollToEmployee(
    @Param('userId') userId: string,
    @Body('baseSalary') baseSalary: number | undefined,
    @Request() req: AuthReq,
  ) {
    return this.payrollService.sendPayrollToEmployee(userId, req.user, baseSalary);
  }

  // ─────────────────────────────────────────────────────────────────
  // SEND PAYROLL TO ALL TEAM — CEO/ADMIN only
  // Each employee receives only their own payroll by email
  // ─────────────────────────────────────────────────────────────────
  @Post('payroll/send-team')
  @Roles(Role.CEO, Role.ADMIN)
  @ApiOperation({ summary: '[CEO/Admin] Email payroll to entire team (each person gets their own)' })
  sendPayrollToTeam(@Request() req: AuthReq) {
    return this.payrollService.sendPayrollToTeam(req.user);
  }

  // Keep old route for backwards compatibility
  @Get('payroll')
  @ApiOperation({ summary: 'My payroll (alias for /payroll/me)' })
  payrollAlias(
    @Query('baseSalary') baseSalary: string | undefined,
    @Request() req: AuthReq,
  ) {
    return this.payrollService.getMonthlyPayroll(
      req.user,
      baseSalary ? parseFloat(baseSalary) : 0,
    );
  }
}
