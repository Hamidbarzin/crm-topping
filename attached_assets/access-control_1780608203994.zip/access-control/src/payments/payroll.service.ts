import { ForbiddenException, Injectable } from '@nestjs/common';
import { Deal, Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { PaymentEngineService } from './payment-engine.service';
import { MailService } from '../mail/mail.service';
import { PaymentBreakdown } from './types/payment.types';

type AuthUser = { userId: string; role: Role };

export interface PayrollDealLine {
  dealId:      string;
  companyName: string;
  stage:       string;
  breakdown:   PaymentBreakdown;
}

export interface MonthlyPayrollReport {
  month:      string;
  employeeId: string;
  fullName:   string;
  baseSalary: number;
  deals:      PayrollDealLine[];
  totals: {
    leadBonus:            number;
    salesCommission:      number;
    closerCommission:     number;
    selfCloseCommission:  number;
    retentionBonus:       number;
    strategicBonus:       number;
    clawback:             number;
    variablePay:          number;
    finalPayment:         number;
    monthlyCredits:       number;
  };
  pendingFounderApprovals: number;
}

@Injectable()
export class PayrollService {
  constructor(
    private prisma:        PrismaService,
    private paymentEngine: PaymentEngineService,
    private mail:          MailService,
  ) {}

  // ─────────────────────────────────────────────────────────────────
  // GET MY PAYROLL — every user can see their own payroll
  // CEO/ADMIN can also see anyone's payroll via getPayrollForUser()
  // ─────────────────────────────────────────────────────────────────
  async getMonthlyPayroll(user: AuthUser, baseSalary = 0): Promise<MonthlyPayrollReport> {
    return this.buildPayrollReport(user.userId, baseSalary);
  }

  // ─────────────────────────────────────────────────────────────────
  // GET PAYROLL FOR A SPECIFIC USER — CEO/ADMIN only
  // Used by the admin panel to preview before sending
  // ─────────────────────────────────────────────────────────────────
  async getPayrollForUser(
    targetUserId: string,
    requester: AuthUser,
    baseSalary = 0,
  ): Promise<MonthlyPayrollReport> {
    if (requester.role !== Role.CEO && requester.role !== Role.ADMIN) {
      // Regular users can only view their own
      if (requester.userId !== targetUserId) {
        throw new ForbiddenException('You can only view your own payroll');
      }
    }
    return this.buildPayrollReport(targetUserId, baseSalary);
  }

  // ─────────────────────────────────────────────────────────────────
  // GET FULL TEAM PAYROLL — CEO/ADMIN only
  // Returns payroll summaries for all active users
  // ─────────────────────────────────────────────────────────────────
  async getTeamPayroll(requester: AuthUser): Promise<MonthlyPayrollReport[]> {
    if (requester.role !== Role.CEO && requester.role !== Role.ADMIN) {
      throw new ForbiddenException('Only CEO/Admin can view team payroll');
    }

    const users = await this.prisma.user.findMany({
      where:   { isActive: true },
      select:  { id: true, baseSalary: true },
      orderBy: { fullName: 'asc' },
    });

    return Promise.all(
      users.map((u) => this.buildPayrollReport(u.id, Number(u.baseSalary))),
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // SEND PAYROLL TO EMPLOYEE — CEO/ADMIN only
  // Employee receives their own payroll by email — they cannot trigger this
  // ─────────────────────────────────────────────────────────────────
  async sendPayrollToEmployee(
    targetUserId: string,
    requester: AuthUser,
    baseSalaryOverride?: number,
  ): Promise<{ sent: boolean; email: string }> {
    // RULE: only CEO or ADMIN can send payroll
    if (requester.role !== Role.CEO && requester.role !== Role.ADMIN) {
      throw new ForbiddenException('Only CEO/Admin can send payroll to employees');
    }

    const targetUser = await this.prisma.user.findUniqueOrThrow({
      where:  { id: targetUserId },
      select: { id: true, fullName: true, email: true, baseSalary: true },
    });

    const baseSalary = baseSalaryOverride ?? Number(targetUser.baseSalary);
    const report     = await this.buildPayrollReport(targetUserId, baseSalary);

    await this.mail.sendPayrollNotification({
      employeeName:  targetUser.fullName,
      employeeEmail: targetUser.email,
      month:         report.month,
      baseSalary:    report.baseSalary,
      totals:        report.totals,
      deals:         report.deals.map((d) => ({
        companyName:  d.companyName,
        finalPayment: d.breakdown.finalPayment,
        status:       d.breakdown.status,
      })),
      sentBy: requester.userId,
    });

    return { sent: true, email: targetUser.email };
  }

  // ─────────────────────────────────────────────────────────────────
  // SEND PAYROLL TO WHOLE TEAM — CEO/ADMIN only
  // Sends each person only their own payroll
  // ─────────────────────────────────────────────────────────────────
  async sendPayrollToTeam(requester: AuthUser): Promise<{ sent: number; failed: number }> {
    if (requester.role !== Role.CEO && requester.role !== Role.ADMIN) {
      throw new ForbiddenException('Only CEO/Admin can send team payroll');
    }

    const users = await this.prisma.user.findMany({
      where:  { isActive: true },
      select: { id: true, fullName: true, email: true, baseSalary: true },
    });

    let sent = 0;
    let failed = 0;

    for (const u of users) {
      try {
        await this.sendPayrollToEmployee(u.id, requester, Number(u.baseSalary));
        sent++;
      } catch {
        failed++;
      }
    }

    return { sent, failed };
  }

  // ─────────────────────────────────────────────────────────────────
  // PRIVATE: build the actual payroll report for a user
  // ─────────────────────────────────────────────────────────────────
  private async buildPayrollReport(
    targetUserId: string,
    baseSalary: number,
  ): Promise<MonthlyPayrollReport> {
    const month  = new Date().toISOString().slice(0, 7);
    const dbUser = await this.prisma.user.findUniqueOrThrow({
      where:  { id: targetUserId },
      select: { fullName: true, canSelfCloseLeads: true },
    });

    const deals = await this.getEligibleDeals(targetUserId);

    const lines: PayrollDealLine[] = deals.map((deal) => ({
      dealId:      deal.id,
      companyName: deal.companyName,
      stage:       deal.stage,
      breakdown:   this.breakdownForDeal(deal, targetUserId, dbUser.canSelfCloseLeads, baseSalary),
    }));

    const totals = lines.reduce(
      (acc, line) => {
        const b = line.breakdown;
        acc.leadBonus           += b.leadBonus;
        acc.salesCommission     += b.salesCommission;
        acc.closerCommission    += b.closerCommission;
        acc.selfCloseCommission += b.selfCloseCommission;
        acc.retentionBonus      += b.retentionBonus;
        acc.strategicBonus      += b.strategicBonus;
        acc.clawback            += b.clawbackAmount;
        acc.monthlyCredits      += b.customerCredits;
        return acc;
      },
      {
        leadBonus: 0, salesCommission: 0, closerCommission: 0,
        selfCloseCommission: 0, retentionBonus: 0, strategicBonus: 0,
        clawback: 0, variablePay: 0, finalPayment: 0, monthlyCredits: 0,
      },
    );

    totals.variablePay =
      totals.leadBonus + totals.salesCommission + totals.closerCommission +
      totals.selfCloseCommission + totals.retentionBonus + totals.strategicBonus;

    totals.finalPayment = Math.max(0, baseSalary + totals.variablePay - totals.clawback);

    const pendingFounderApprovals = deals.filter(
      (d) => d.founderApprovalStatus === 'PENDING',
    ).length;

    return {
      month,
      employeeId: targetUserId,
      fullName:   dbUser.fullName,
      baseSalary,
      deals:      lines,
      totals,
      pendingFounderApprovals,
    };
  }

  // Only deals where user is an owner AND won/invoiced this month
  private async getEligibleDeals(userId: string): Promise<Deal[]> {
    return this.prisma.deal.findMany({
      where: {
        AND: [
          {
            OR: [
              { leadOwnerId:   userId },
              { salesOwnerId:  userId },
              { closerOwnerId: userId },
            ],
          },
          {
            OR: [{ stage: 'WON' as const }, { invoicePaidThisMonth: true }],
          },
        ],
      },
      orderBy: { updatedAt: 'desc' },
    });
  }

  private breakdownForDeal(
    deal: Deal,
    userId: string,
    canSelfCloseLeads: boolean,
    baseSalary: number,
  ): PaymentBreakdown {
    return this.paymentEngine.calculate({
      employeeId:               userId,
      leadOwner:                deal.leadOwnerId,
      salesOwner:               deal.salesOwnerId,
      closerOwner:              deal.closerOwnerId,
      collectedPreTaxRevenue:   Number(deal.collectedPreTaxRevenue),
      customerMonthlyRevenue:   deal.customerMonthlyRevenue ? Number(deal.customerMonthlyRevenue) : undefined,
      grossMarginPercent:       Number(deal.grossMarginPercent),
      invoicePaid:              deal.invoicePaid,
      invoicePaidThisMonth:     deal.invoicePaidThisMonth,
      ordersCompleted:          deal.ordersCompleted,
      dailyStops:               deal.dailyStops ?? deal.ordersCompleted,
      usesShopify:              deal.usesShopify,
      hasWarehouse:             deal.hasWarehouse,
      customerStatus:           deal.customerStatus,
      crmProof:                 deal.crmProof,
      founderApproval:          deal.founderApproval,
      disputeOrRefund:          deal.disputeOrRefund,
      daysActive:               deal.daysActive,
      retained90Days:           deal.retained90Days,
      isFounderLedCustomer:     deal.isFounderLedCustomer,
      employeeHadDocumentedRole: [deal.leadOwnerId, deal.salesOwnerId, deal.closerOwnerId].includes(userId),
      existingClawbackAmount:   Number(deal.clawbackAmount),
      baseSalary,
      canSelfCloseLeads:        deal.leadOwnerId === userId && canSelfCloseLeads,
    });
  }
}
