// ─────────────────────────────────────────────────────────────────
// ADD THIS METHOD to the existing MailService class in mail.service.ts
// Paste it after sendCrmSubmissionNotification()
// ─────────────────────────────────────────────────────────────────

export interface PayrollEmailPayload {
  employeeName:  string;
  employeeEmail: string;
  month:         string;   // "2026-06"
  baseSalary:    number;
  totals: {
    leadBonus:            number;
    salesCommission:      number;
    closerCommission:     number;
    selfCloseCommission:  number;
    retentionBonus:       number;
    strategicBonus:       number;
    clawback:             number;
    variablePay:          number;
    finalPayment:         number;
    monthlyCredits:       number;
  };
  deals: Array<{ companyName: string; finalPayment: number; status: string }>;
  sentBy: string;
}

// ─────────────────────────────────────────────────────────────────
// Copy this method into MailService:
// ─────────────────────────────────────────────────────────────────

/*
async sendPayrollNotification(p: PayrollEmailPayload): Promise<boolean> {
  const subject = `[Topping] Payroll — ${p.employeeName} — ${p.month}`;

  const rows = [
    ['حقوق پایه',           `$${Math.round(p.baseSalary).toLocaleString('en-CA')}`],
    ['بونس لید',             `$${Math.round(p.totals.leadBonus)}`],
    ['کمیسیون فروش',        `$${Math.round(p.totals.salesCommission + p.totals.closerCommission + p.totals.selfCloseCommission)}`],
    ['بونس نگهداشت',        `$${Math.round(p.totals.retentionBonus)}`],
    ['بونس استراتژیک',      `$${Math.round(p.totals.strategicBonus)}`],
    ['کسر Clawback',        `-$${Math.round(p.totals.clawback)}`],
    ['────────────────────', '──────────'],
    ['جمع متغیر',           `$${Math.round(p.totals.variablePay)}`],
    ['پرداخت نهایی',        `$${Math.round(p.totals.finalPayment).toLocaleString('en-CA')}`],
    ['کردیت ماهانه',        `${p.totals.monthlyCredits} credits`],
  ];

  const tableHtml = rows.map(([k, v]) =>
    `<tr><td style="padding:6px 12px;color:#555;border-bottom:1px solid #eee">${k}</td>
     <td style="padding:6px 12px;font-weight:600;text-align:right;border-bottom:1px solid #eee">${v}</td></tr>`
  ).join('');

  const dealsHtml = p.deals.length
    ? `<h3 style="font-size:15px;margin:20px 0 8px">Deal‌های این ماه</h3>
       <ul style="font-size:13px;color:#555;line-height:2">
         ${p.deals.map(d =>
           `<li>${escapeHtml(d.companyName)} — $${Math.round(d.finalPayment)} (${d.status})</li>`
         ).join('')}
       </ul>`
    : '<p style="color:#888;font-size:13px">هیچ deal واجد شرایطی این ماه ندارید.</p>';

  const html = `
    <div dir="rtl" style="font-family:Tahoma,sans-serif;max-width:560px;margin:auto">
      <h2 style="color:#1a1a2e">حقوق و مزایا — ${escapeHtml(p.employeeName)}</h2>
      <p style="color:#555;font-size:14px">دوره: ${p.month}</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;font-size:14px">
        ${tableHtml}
      </table>
      ${dealsHtml}
      <p style="color:#aaa;font-size:11px;margin-top:24px">
        ارسال‌شده توسط مدیر · Topping OS · ${new Date().toLocaleString('fa-IR')}
      </p>
    </div>`;

  const text = rows.map(([k, v]) => `${k}: ${v}`).join('\n') +
    '\n\nDeal‌ها:\n' +
    p.deals.map(d => `- ${d.companyName}: $${Math.round(d.finalPayment)}`).join('\n');

  return this.sendMail([p.employeeEmail], subject, text, html);
}
*/
