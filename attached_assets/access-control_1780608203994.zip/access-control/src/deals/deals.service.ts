import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  ClawbackStatus,
  Deal,
  DealStage,
  DealSubmissionStatus,
  FounderApprovalStatus,
  Role,
} from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { PaymentEngineService } from '../payments/payment-engine.service';
import { DealCreditsService } from './deal-credits.service';
import { ApplyClawbackDto, CreateDealDto, UpdateDealDto } from './dto/deal.dto';
import { MailService } from '../mail/mail.service';

type AuthUser = { userId: string; role: Role };

// ─────────────────────────────────────────────────────────────────
// ACCESS CONTROL RULES
//
// ┌─────────────┬──────────────────────────────────────────────────┐
// │ Role        │ Can see                                          │
// ├─────────────┼──────────────────────────────────────────────────┤
// │ CEO / ADMIN │ All deals                                        │
// │ MANAGER     │ Only deals where they are lead/sales/closer/creator│
// │ SALES       │ Only deals where they are lead/sales/closer/creator│
// └─────────────┴──────────────────────────────────────────────────┘
//
// Payroll: only CEO/ADMIN can call sendPayroll() — never the employee.
// ─────────────────────────────────────────────────────────────────

@Injectable()
export class DealsService {
  constructor(
    private prisma: PrismaService,
    private paymentEngine: PaymentEngineService,
    private dealCredits: DealCreditsService,
    private mail: MailService,
  ) {}

  // ── Helpers ─────────────────────────────────────────────────────

  /** Build a Prisma `where` clause that enforces ownership visibility */
  private ownershipWhere(userId: string) {
    return {
      OR: [
        { leadOwnerId: userId },
        { salesOwnerId: userId },
        { closerOwnerId: userId },
        { createdById: userId },
      ],
    };
  }

  /** Returns true if user is CEO or ADMIN */
  private isAdmin(role: Role) {
    return role === Role.CEO || role === Role.ADMIN;
  }

  /** Throw if user has no ownership over this deal */
  private assertOwnership(deal: Deal, user: AuthUser) {
    if (this.isAdmin(user.role)) return; // CEO/ADMIN sees all
    const owners = [deal.leadOwnerId, deal.salesOwnerId, deal.closerOwnerId, deal.createdById];
    if (!owners.includes(user.userId)) {
      throw new ForbiddenException('You do not have access to this deal');
    }
  }

  private async getDealOrThrow(id: string): Promise<Deal> {
    const deal = await this.prisma.deal.findUnique({ where: { id } });
    if (!deal) throw new NotFoundException('Deal not found');
    return deal;
  }

  // ── Team members (for dropdown assignment) ─────────────────────

  async findTeamMembers() {
    return this.prisma.user.findMany({
      where: { isActive: true },
      select: { id: true, fullName: true, email: true, role: true },
      orderBy: { fullName: 'asc' },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // GET ALL — user sees only their own deals
  // CEO/ADMIN see everything
  // ─────────────────────────────────────────────────────────────────
  async findAll(user: AuthUser) {
    const where = this.isAdmin(user.role) ? {} : this.ownershipWhere(user.userId);

    return this.prisma.deal.findMany({
      where,
      include: {
        clawbacks:         { orderBy: { createdAt: 'desc' }, take: 5 },
        creditAllocations: true,
      },
      orderBy: { updatedAt: 'desc' },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // GET ONE — user must be an owner
  // ─────────────────────────────────────────────────────────────────
  async findOne(id: string, user: AuthUser) {
    const deal = await this.getDealOrThrow(id);
    this.assertOwnership(deal, user);

    return this.prisma.deal.findUnique({
      where: { id },
      include: {
        clawbacks:         { orderBy: { createdAt: 'desc' } },
        creditAllocations: true,
      },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // CREATE — any authenticated user can create
  // They are automatically set as one of the owners
  // ─────────────────────────────────────────────────────────────────
  async create(dto: CreateDealDto, user: AuthUser) {
    const approvalMeta = this.resolveFounderApprovalMeta({
      collectedPreTaxRevenue: dto.collectedPreTaxRevenue ?? 0,
      grossMarginPercent:     dto.grossMarginPercent ?? 0,
    });

    return this.prisma.deal.create({
      data: {
        companyName:            dto.companyName,
        stage:                  dto.stage ?? DealStage.LEAD,
        leadOwnerId:            dto.leadOwnerId  ?? user.userId,
        salesOwnerId:           dto.salesOwnerId ?? user.userId,
        closerOwnerId:          dto.closerOwnerId ?? user.userId,
        collectedPreTaxRevenue: dto.collectedPreTaxRevenue ?? 0,
        grossMarginPercent:     dto.grossMarginPercent ?? 0,
        invoicePaid:            dto.invoicePaid ?? false,
        ordersCompleted:        dto.ordersCompleted ?? 0,
        crmProof:               dto.crmProof ?? false,
        notes:                  dto.notes,
        createdById:            user.userId,
        ...approvalMeta,
      },
      include: { clawbacks: true },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // UPDATE — user must be an owner AND deal must not be submitted/approved
  // ─────────────────────────────────────────────────────────────────
  async update(id: string, dto: UpdateDealDto, user: AuthUser) {
    const deal = await this.getDealOrThrow(id);
    this.assertOwnership(deal, user);

    if (
      deal.submissionStatus === DealSubmissionStatus.SUBMITTED ||
      deal.submissionStatus === DealSubmissionStatus.APPROVED
    ) {
      throw new BadRequestException(
        'Cannot edit while submitted or approved. Wait for manager review or rejection.',
      );
    }

    const approvalMeta = this.resolveFounderApprovalMeta({
      collectedPreTaxRevenue: dto.collectedPreTaxRevenue ?? Number(deal.collectedPreTaxRevenue),
      grossMarginPercent:     dto.grossMarginPercent     ?? Number(deal.grossMarginPercent),
    });

    return this.prisma.deal.update({
      where: { id },
      data: { ...dto, ...approvalMeta },
      include: { clawbacks: true, creditAllocations: true },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // SUBMIT — user must be an owner
  // After submit, CEO/ADMIN must approve — user cannot trigger this themselves
  // ─────────────────────────────────────────────────────────────────
  async submitForReview(id: string, user: AuthUser) {
    const deal = await this.getDealOrThrow(id);
    this.assertOwnership(deal, user);

    if (deal.submissionStatus !== DealSubmissionStatus.DRAFT) {
      throw new BadRequestException(
        `Deal is already ${deal.submissionStatus.toLowerCase()} — cannot re-submit`,
      );
    }

    const updated = await this.prisma.deal.update({
      where: { id },
      data: {
        submissionStatus: DealSubmissionStatus.SUBMITTED,
        submittedAt:      new Date(),
        submittedById:    user.userId,
      },
    });

    // Notify CEO/ADMIN by email
    const submitter = await this.prisma.user.findUnique({
      where: { id: user.userId },
      select: { fullName: true, email: true },
    });
    void this.mail.sendCrmSubmissionNotification({
      submitterName:   submitter?.fullName ?? 'Team member',
      submitterEmail:  submitter?.email    ?? '',
      companyName:     deal.companyName,
      activityReport:  deal.activityReport ?? '',
      collectedRevenue: Number(deal.collectedPreTaxRevenue),
      creditsPreview:  [],
      dealId:          deal.id,
    });

    return updated;
  }

  // ─────────────────────────────────────────────────────────────────
  // REVIEW — CEO/ADMIN only
  // Employees CANNOT approve their own payroll/credits
  // ─────────────────────────────────────────────────────────────────
  async reviewSubmission(
    id: string,
    approved: boolean,
    user: AuthUser,
    notes?: string,
  ) {
    if (!this.isAdmin(user.role)) {
      throw new ForbiddenException('Only CEO or Admin can approve CRM submissions');
    }

    const deal = await this.getDealOrThrow(id);

    if (deal.submissionStatus !== DealSubmissionStatus.SUBMITTED) {
      throw new BadRequestException('Deal is not in SUBMITTED state');
    }

    return this.prisma.$transaction(async (tx) => {
      const updated = await tx.deal.update({
        where: { id },
        data: {
          submissionStatus: approved
            ? DealSubmissionStatus.APPROVED
            : DealSubmissionStatus.REJECTED,
          reviewedById: user.userId,
          reviewedAt:   new Date(),
          reviewNotes:  notes,
        },
      });

      if (approved) {
        await this.dealCredits.allocateCredits(id, tx);
      }

      return updated;
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // CREDIT PREVIEW — user must be an owner
  // ─────────────────────────────────────────────────────────────────
  async getCreditPreview(id: string, user: AuthUser) {
    const deal = await this.getDealOrThrow(id);
    this.assertOwnership(deal, user);
    return this.dealCredits.previewCredits(id);
  }

  // ─────────────────────────────────────────────────────────────────
  // CALCULATE PAYMENT — user must be an owner
  // Returns breakdown only for the requesting user's share
  // ─────────────────────────────────────────────────────────────────
  async calculatePayment(id: string, user: AuthUser, baseSalary = 0) {
    const deal = await this.getDealOrThrow(id);
    this.assertOwnership(deal, user);

    const dbUser = await this.prisma.user.findUnique({ where: { id: user.userId } });
    const canSelfClose = dbUser?.canSelfCloseLeads ?? false;

    return this.paymentEngine.calculate({
      employeeId:               user.userId,
      employeeRole:             user.role,
      leadOwner:                deal.leadOwnerId,
      salesOwner:               deal.salesOwnerId,
      closerOwner:              deal.closerOwnerId,
      collectedPreTaxRevenue:   Number(deal.collectedPreTaxRevenue),
      customerMonthlyRevenue:   deal.customerMonthlyRevenue ? Number(deal.customerMonthlyRevenue) : undefined,
      grossMarginPercent:       Number(deal.grossMarginPercent),
      invoicePaid:              deal.invoicePaid,
      invoicePaidThisMonth:     deal.invoicePaidThisMonth,
      ordersCompleted:          deal.ordersCompleted,
      dailyStops:               deal.dailyStops ?? deal.ordersCompleted,
      usesShopify:              deal.usesShopify,
      hasWarehouse:             deal.hasWarehouse,
      customerStatus:           deal.customerStatus,
      crmProof:                 deal.crmProof,
      founderApproval:          deal.founderApproval,
      disputeOrRefund:          deal.disputeOrRefund,
      daysActive:               deal.daysActive,
      retained90Days:           deal.retained90Days,
      isFounderLedCustomer:     deal.isFounderLedCustomer,
      employeeHadDocumentedRole: [deal.leadOwnerId, deal.salesOwnerId, deal.closerOwnerId].includes(user.userId),
      existingClawbackAmount:   Number(deal.clawbackAmount),
      baseSalary,
      canSelfCloseLeads:        deal.leadOwnerId === user.userId && canSelfClose,
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // MY APPROVED CREDITS — user sees only their own
  // ─────────────────────────────────────────────────────────────────
  async getMyApprovedCredits(user: AuthUser) {
    // CEO/ADMIN can see all allocations; everyone else only their own
    const where = this.isAdmin(user.role)
      ? { deal: { submissionStatus: DealSubmissionStatus.APPROVED } }
      : {
          userId: user.userId,
          deal:   { submissionStatus: DealSubmissionStatus.APPROVED },
        };

    return this.prisma.dealCreditAllocation.findMany({
      where,
      include: {
        deal: { select: { companyName: true, stage: true, collectedPreTaxRevenue: true } },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // PENDING SUBMISSIONS — CEO/ADMIN only
  // ─────────────────────────────────────────────────────────────────
  async findPendingSubmissions(user: AuthUser) {
    if (!this.isAdmin(user.role)) {
      throw new ForbiddenException('Only CEO/Admin can view pending submissions');
    }
    return this.prisma.deal.findMany({
      where:    { submissionStatus: DealSubmissionStatus.SUBMITTED },
      orderBy:  { submittedAt: 'asc' },
      include:  { creditAllocations: true },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // PENDING FOUNDER APPROVALS — CEO/ADMIN only
  // ─────────────────────────────────────────────────────────────────
  async findPendingFounderApprovals(user: AuthUser) {
    if (!this.isAdmin(user.role)) {
      throw new ForbiddenException('Only CEO/Admin can view approval queue');
    }
    return this.prisma.deal.findMany({
      where:   { founderApprovalStatus: FounderApprovalStatus.PENDING },
      orderBy: { updatedAt: 'desc' },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // STAGE UPDATE — must be an owner
  // ─────────────────────────────────────────────────────────────────
  async updateStage(id: string, stage: DealStage, user: AuthUser) {
    const deal = await this.getDealOrThrow(id);
    this.assertOwnership(deal, user);
    return this.prisma.deal.update({ where: { id }, data: { stage } });
  }

  // ─────────────────────────────────────────────────────────────────
  // FOUNDER APPROVAL — CEO/ADMIN only
  // ─────────────────────────────────────────────────────────────────
  async setFounderApproval(id: string, approved: boolean, user: AuthUser) {
    if (!this.isAdmin(user.role)) {
      throw new ForbiddenException('Only CEO/Admin can set founder approval');
    }
    const deal = await this.getDealOrThrow(id);

    return this.prisma.deal.update({
      where: { id },
      data: {
        founderApproval:       approved,
        founderApprovalStatus: approved
          ? FounderApprovalStatus.APPROVED
          : FounderApprovalStatus.REJECTED,
        founderApprovedById:   user.userId,
        founderApprovedAt:     new Date(),
      },
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // CLAWBACK — CEO/ADMIN only
  // ─────────────────────────────────────────────────────────────────
  async applyClawback(id: string, dto: ApplyClawbackDto, user: AuthUser) {
    if (!this.isAdmin(user.role)) {
      throw new ForbiddenException('Only CEO/Admin can apply clawbacks');
    }

    const deal = await this.getDealOrThrow(id);

    return this.prisma.$transaction(async (tx) => {
      await tx.clawbackRecord.create({
        data: {
          dealId:      deal.id,
          userId:      dto.userId,
          amount:      dto.amount,
          reason:      dto.reason,
          status:      ClawbackStatus.APPLIED,
          createdById: user.userId,
          appliedAt:   new Date(),
        },
      });

      return tx.deal.update({
        where: { id },
        data:  { clawbackAmount: Number(deal.clawbackAmount) + dto.amount },
      });
    });
  }

  // ── Private helpers ─────────────────────────────────────────────

  private resolveFounderApprovalMeta(params: {
    collectedPreTaxRevenue: number;
    grossMarginPercent: number;
  }) {
    const needsApproval =
      params.grossMarginPercent < 35 || params.collectedPreTaxRevenue >= 10000;

    return needsApproval
      ? { founderApprovalStatus: FounderApprovalStatus.PENDING, founderApproval: false }
      : { founderApprovalStatus: FounderApprovalStatus.NOT_REQUIRED, founderApproval: true };
  }
}
